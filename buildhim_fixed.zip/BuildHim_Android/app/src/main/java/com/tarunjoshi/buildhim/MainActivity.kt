package com.tarunjoshi.buildhim

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

private val bg = Color(0xFF0B0C10)
private val panel = Color(0xFF171922)
private val muted = Color(0xFF9699A8)
private val accent = Color(0xFFBDA7FF)

/*
 * Set this to the raw URL of your public prompts.json file after creating
 * the free GitHub feed repository. Keep it empty until the feed is hosted.
 */
private const val PROMPT_FEED_URL = ""

data class Prompt(
    val id: String,
    val title: String,
    val category: String,
    val image: String,
    val prompt: String,
    val negative: String,
    val ratio: String,
    val tags: String,
    val trending: Boolean,
    val trendScore: Int,
    val publishedAt: Long
)

private val starterPrompts = listOf(
    Prompt("p01","Cinematic Rain Portrait","Portrait","https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=900",
        "Use the uploaded reference photo to preserve the person's exact identity and facial features. Create a photorealistic cinematic close-up portrait in a rain-soaked city at night, subtle water droplets, soft blue and amber practical lights, natural skin texture, shallow depth of field, 85mm lens, editorial color grading. Do not change face shape or identity.",
        "different person, altered identity, face distortion, plastic skin, over-smoothed skin, extra features, text, watermark, blurry face","4:5","portrait, cinematic, realistic",true,98,20),
    Prompt("p02","Anime Warrior Key Art","Anime","https://images.unsplash.com/photo-1578632767115-351597cf2477?w=900",
        "Create an original high-detail anime hero portrait using the uploaded image only as a loose identity reference. Dynamic confident pose, layered dark outfit, dramatic rim lighting, wind-swept hair, expressive eyes, richly detailed hand-painted anime key visual, cinematic composition.",
        "low detail, deformed hands, extra fingers, blurry eyes, text, watermark","3:4","anime, character, illustration",true,95,19),
    Prompt("p03","Luxury Car Editorial","Cars","https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900",
        "Premium automotive editorial photograph of the exact car in the reference, low camera angle on a clean modern road at golden hour, dramatic reflections across the bodywork, realistic tires and proportions, subtle motion in the background, luxury campaign photography, crisp focus.",
        "wrong car model, distorted wheels, extra wheels, warped body, text, watermark, oversaturated","16:9","cars, luxury, editorial",true,92,18),
    Prompt("p04","Cosmic Fantasy Landscape","Fantasy","https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=900",
        "A vast original fantasy world beneath a luminous cosmic sky, towering distant mountains, strange ancient architecture, atmospheric haze, glowing celestial light, intricate environmental storytelling, cinematic concept art, deep scale and rich detail.",
        "low resolution, flat lighting, clutter, text, logo, watermark","16:9","fantasy, landscape, cosmic",true,90,17),
    Prompt("p05","Alpine Cloudscape","Nature","https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=900",
        "Photorealistic majestic alpine mountain peaks rising above a sea of clouds at sunrise, delicate golden light touching the summits, atmospheric depth, natural colors, fine landscape detail, premium travel photography, balanced composition.",
        "cartoon, oversaturated colors, artificial mountains, text, watermark, low detail","9:16","nature, mountains, wallpaper",false,70,16),
    Prompt("p06","High Fashion Studio","Fashion","https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=900",
        "Use the uploaded photo to retain the same person's identity. Create a high-fashion magazine editorial portrait, refined contemporary outfit, elegant studio backdrop, sculpted softbox lighting, natural skin texture, confident relaxed pose, 85mm lens, sophisticated color grade.",
        "different identity, face swap, distorted hands, plastic skin, extra limbs, text, watermark","4:5","fashion, editorial, portrait",true,87,15),
    Prompt("p07","Neon Future City","Sci-Fi","https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=900",
        "A breathtaking futuristic megacity at night, layered glowing architecture, atmospheric rain haze, subtle neon reflections, tiny human silhouettes for scale, cinematic science-fiction film still, intricate believable details, wide establishing shot.",
        "flat scene, unreadable text, oversaturated neon, low detail, watermark","16:9","sci-fi, city, neon",false,65,14),
    Prompt("p08","Minimal Product Campaign","Product","https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900",
        "Premium minimalist product advertising photograph of the exact uploaded product, centered hero composition, seamless studio background, soft directional softbox lighting, precise realistic shadow, accurate product shape and branding, luxury commercial photography.",
        "changed product design, invented logo, extra objects, warped geometry, text, watermark","1:1","product, studio, commercial",false,60,13),
    Prompt("p09","Turquoise Ocean Wallpaper","Wallpaper","https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=900",
        "High-resolution aerial ocean wallpaper, turquoise waves meeting a pale sandy shoreline, intricate natural foam patterns, sunlight shimmering on water, clean uncluttered composition, realistic coastal photography, beautiful negative space.",
        "buildings, boats, people, text, watermark, artificial colors","9:16","wallpaper, ocean, minimal",false,55,12),
    Prompt("p10","Ancient Temple at Dawn","Mythology","https://images.unsplash.com/photo-1548013146-72479768bada?w=900",
        "A majestic ancient Indian stone temple at dawn, intricate carved pillars and sculptural details, soft golden sun rays passing through morning mist, devotional yet cinematic atmosphere, historically inspired architecture, ultra-detailed environment concept art.",
        "modern buildings, incorrect anatomy in statues, text, watermark, low detail","4:5","mythology, temple, cinematic",true,82,11),
    Prompt("p11","Monochrome Street Portrait","Portrait","https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=900",
        "Preserve the uploaded person's identity exactly. Create a striking black-and-white street-style portrait, candid confident expression, textured urban background, directional natural light, authentic pores and skin texture, subtle film grain, timeless magazine photography.",
        "different face, changed identity, waxy skin, blur, extra fingers, text, watermark","4:5","portrait, monochrome, street",false,50,10),
    Prompt("p12","Dreamy Sakura Anime","Anime","https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=900",
        "Dreamlike anime environment in a quiet Japanese street during cherry blossom season, delicate petals drifting through warm afternoon light, detailed traditional architecture, gentle atmospheric perspective, beautiful hand-painted background art, cinematic framing.",
        "low quality, harsh outlines, clutter, text, watermark","9:16","anime, sakura, scenery",false,48,9),
    Prompt("p13","Golden Hour Motorcycle","Cars","https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=900",
        "Premium motorcycle photography, the exact bike from the reference standing on an open road at golden hour, low three-quarter angle, realistic metal and paint reflections, dramatic long shadows, crisp commercial automotive detail.",
        "wrong motorcycle, malformed wheels, extra parts, warped frame, text, watermark","4:5","motorcycle, automotive, golden hour",false,45,8),
    Prompt("p14","Enchanted Forest","Fantasy","https://images.unsplash.com/photo-1448375240586-882707db888b?w=900",
        "An enchanted ancient forest with towering trees, delicate shafts of volumetric sunlight, soft ground mist, tiny glowing particles, mysterious path leading into the distance, richly textured fantasy environment concept art, cinematic depth.",
        "flat lighting, oversaturated, artificial plastic plants, text, watermark","16:9","fantasy, forest, magical",false,42,7),
    Prompt("p15","Luxury Watch Campaign","Product","https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=900",
        "Luxury watch product campaign, preserve the exact watch design from the reference, macro three-quarter view, dark elegant studio setting, controlled reflections on metal and glass, dramatic premium lighting, precise craftsmanship detail, commercial photography.",
        "altered dial, wrong time markings, extra hands, distorted strap, text, watermark","1:1","watch, luxury, product",false,40,6),
    Prompt("p16","Golden Temple Reflection","Mythology","https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=900",
        "A serene sacred Indian temple reflected in still water at sunrise, warm golden illumination, intricate architecture, delicate morning mist, peaceful devotional atmosphere, cinematic wide composition, photorealistic environment.",
        "crowds, modern structures, distorted architecture, text, watermark","16:9","temple, devotional, sunrise",false,38,5),
    Prompt("p17","Editorial Outfit Portrait","Fashion","https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=900",
        "Use the reference photo to keep the same person's face and identity. Create a full-body contemporary fashion editorial, tasteful layered outfit, confident natural stance, clean architectural backdrop, soft directional daylight, premium magazine styling, realistic fabric folds.",
        "different person, changed face, extra limbs, broken hands, plastic fabric, text, watermark","4:5","fashion, full body, editorial",false,35,4),
    Prompt("p18","Aurora Night Sky","Nature","https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=900",
        "A breathtaking natural aurora borealis flowing over a remote mountain lake at night, stars visible in a clear sky, subtle reflections on calm water, realistic long-exposure landscape photography, balanced exposure and natural color.",
        "city lights, artificial gradients, oversaturated green, text, watermark","9:16","nature, aurora, night",false,32,3),
    Prompt("p19","Retro Futuristic Robot","Sci-Fi","https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=900",
        "Original retro-futuristic robot character portrait, beautifully engineered brushed metal surfaces, expressive illuminated eyes, cinematic studio lighting, detailed mechanical craftsmanship, atmospheric science-fiction concept art, centered composition.",
        "broken geometry, extra limbs, melted metal, text, watermark, low detail","3:4","robot, sci-fi, character",false,30,2),
    Prompt("p20","Clean Minimal Phone Wallpaper","Wallpaper","https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=900",
        "Minimal premium smartphone wallpaper of a peaceful mountain landscape, soft atmospheric gradients, elegant natural negative space, subtle sunrise glow, clean horizon, realistic photography, carefully balanced composition with no text.",
        "text, logo, watermark, clutter, oversaturated colors, low resolution","9:16","wallpaper, minimal, landscape",false,28,1)
)

private fun parseFeed(raw: String): List<Prompt> {
    val array = JSONObject(raw).optJSONArray("prompts") ?: JSONArray()
    val result = mutableListOf<Prompt>()
    val ids = mutableSetOf<String>()
    val images = mutableSetOf<String>()
    for (i in 0 until array.length()) {
        val o = array.optJSONObject(i) ?: continue
        val id = o.optString("id").trim()
        val image = o.optString("imageUrl").trim()
        val prompt = o.optString("prompt").trim()
        // One JSON object owns both imageUrl and prompt: never pair records by list position.
        if (id.isBlank() || image.isBlank() || prompt.isBlank()) continue
        if (!image.startsWith("https://") || !ids.add(id) || !images.add(image)) continue
        result += Prompt(
            id = id,
            title = o.optString("title", "AI Inspiration"),
            category = o.optString("category", "Other"),
            image = image,
            prompt = prompt,
            negative = o.optString("negativePrompt", ""),
            ratio = o.optString("aspectRatio", "4:5"),
            tags = o.optString("tags", ""),
            trending = o.optBoolean("trending", false),
            trendScore = o.optInt("trendScore", 0).coerceIn(0, 100),
            publishedAt = o.optLong("publishedAt", 0L)
        )
    }
    return result
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BuildHimApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildHimApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("build_him", Context.MODE_PRIVATE) }
    var savedIds by remember { mutableStateOf(prefs.getStringSet("saved_ids", emptySet())?.toSet() ?: emptySet()) }
    var category by remember { mutableStateOf("For You") }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Prompt?>(null) }
    var savedPage by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var prompts by remember { mutableStateOf(starterPrompts) }
    var feedStatus by remember { mutableStateOf("Starter collection") }
    val categories = listOf("For You","Trending","Portrait","Anime","Mythology","Fantasy","Sci-Fi","Cars","Fashion","Nature","Product","Wallpaper")

    LaunchedEffect(refreshKey) {
        if (PROMPT_FEED_URL.isNotBlank()) {
            feedStatus = "Updating collection…"
            val remote = withContext(Dispatchers.IO) {
                runCatching {
                    URL(PROMPT_FEED_URL).openConnection().apply {
                        connectTimeout = 7000
                        readTimeout = 10000
                        setRequestProperty("Cache-Control", "no-cache")
                    }.getInputStream().bufferedReader().use { parseFeed(it.readText()) }
                }.getOrDefault(emptyList())
            }
            if (remote.isNotEmpty()) {
                prompts = remote
                feedStatus = "Updated collection"
            } else {
                feedStatus = "Offline collection"
            }
        }
    }

    val ordered = prompts.sortedWith(compareByDescending<Prompt> { it.trending }.thenByDescending { it.trendScore }.thenByDescending { it.publishedAt })
    val filtered = ordered.filter { p ->
        val categoryMatch = when (category) {
            "For You" -> true
            "Trending" -> p.trending
            else -> p.category.equals(category, true)
        }
        val searchMatch = query.isBlank() || listOf(p.title,p.category,p.prompt,p.tags).any { it.contains(query, true) }
        categoryMatch && searchMatch && (!savedPage || savedIds.contains(p.id))
    }

    fun toggleSave(p: Prompt) {
        val next = if (savedIds.contains(p.id)) savedIds - p.id else savedIds + p.id
        savedIds = next
        prefs.edit().putStringSet("saved_ids", next).apply()
    }

    Scaffold(
        containerColor = bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF14151B)) {
                NavigationBarItem(selected = !savedPage, onClick = { savedPage = false }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Discover") })
                NavigationBarItem(selected = savedPage, onClick = { savedPage = true }, icon = { Icon(Icons.Default.Bookmark, null) }, label = { Text("Saved") })
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BUILD HIM", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("CREATED BY TARUN JOSHI", color = accent, fontSize = 9.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { refreshKey++ }) { Icon(Icons.Default.Refresh, "Refresh prompts", tint = accent) }
            }
            Text(if (savedPage) "Your collection" else "Find your next look.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 18.dp, top = 3.dp))
            Text(if (savedPage) "Saved inspiration images." else "Tap an image to reveal its matching prompt.", color = muted, fontSize = 12.sp, modifier = Modifier.padding(start = 18.dp, top = 4.dp, bottom = 12.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                singleLine = true, placeholder = { Text("Search styles and categories...", fontSize = 12.sp, color = muted) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = muted) },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accent, unfocusedBorderColor = panel,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedContainerColor = panel, unfocusedContainerColor = panel, cursorColor = accent
                )
            )
            if (!savedPage) {
                LazyRow(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(categories) { c ->
                        FilterChip(
                            selected = category == c, onClick = { category = c },
                            label = { Text(c, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accent, selectedLabelColor = bg, containerColor = panel, labelColor = Color.White),
                            border = null
                        )
                    }
                }
            }
            Text(feedStatus, color = muted, fontSize = 9.sp, modifier = Modifier.padding(start = 17.dp, bottom = 5.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (savedPage) "No saved images yet." else "No images found.", color = muted) }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { p ->
                        // Image-only card: prompt and title are deliberately hidden until tap.
                        Box(Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(15.dp)).background(panel).clickable { selected = p }) {
                            AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (p.trending) {
                                Surface(
                                    modifier = Modifier.align(Alignment.TopStart).padding(7.dp),
                                    color = Color(0xDD17131F), shape = RoundedCornerShape(7.dp)
                                ) {
                                    Row(Modifier.padding(horizontal = 7.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.TrendingUp, null, tint = accent, modifier = Modifier.size(11.dp))
                                        Spacer(Modifier.width(3.dp))
                                        Text("TRENDING", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            IconButton(
                                onClick = { toggleSave(p) },
                                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(32.dp).background(Color(0xAA101116), RoundedCornerShape(50))
                            ) {
                                Icon(if (savedIds.contains(p.id)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Color.White, modifier = Modifier.size(17.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    selected?.let { p ->
        val clipboard = LocalClipboardManager.current
        Dialog(onDismissRequest = { selected = null }) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(panel).padding(14.dp)) {
                AsyncImage(p.image, p.title, Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(15.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("${p.category}  •  ${p.ratio}", color = accent, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                    }
                    IconButton(onClick = { toggleSave(p) }) {
                        Icon(if (savedIds.contains(p.id)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = accent)
                    }
                }
                Text(p.tags, color = muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 9.dp))
                Text("MATCHING PROMPT", color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(p.prompt, color = Color.White, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 6.dp).heightIn(max = 125.dp).verticalScroll(rememberScrollState()))
                Spacer(Modifier.height(10.dp))
                Button(onClick = { clipboard.setText(AnnotatedString(p.prompt)) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = bg), shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("Copy Prompt", fontWeight = FontWeight.Bold)
                }
                if (p.negative.isNotBlank()) {
                    OutlinedButton(onClick = { clipboard.setText(AnnotatedString(p.negative)) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                        Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("Copy Negative Prompt")
                    }
                }
                Text("Use this prompt with your own photo in any AI image tool.", color = muted, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 5.dp))
                TextButton(onClick = { selected = null }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Close", color = muted) }
            }
        }
    }
}
