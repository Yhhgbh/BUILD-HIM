# BUILD HIM — image-first AI prompt discovery app
**Created by Tarun Joshi**

## Exact user experience
- App opens on an image-only discovery feed. Prompt text is hidden.
- Tap a picture to open its details and reveal the prompt that belongs to that exact image.
- Copy the prompt (and optional negative prompt) and use it in any AI image tool with the user's own reference photo.
- No user login, Google account, subscription, payment, or AI-generation API key is needed.
- Saved images are stored locally on the device.

## Matching rule
Every catalogue item stores `imageUrl` and `prompt` together in the **same JSON object**. The app never joins images and prompts by array position. It rejects entries with missing IDs, missing prompts, non-HTTPS images, duplicate IDs or duplicate image URLs. A human content editor must still check that the actual image visually represents the written prompt before publishing it; metadata checks cannot judge image meaning.

## Trending and continuous updates
- Feed order: `trending=true` first, then `trendScore` high to low, then newest `publishedAt`.
- Only items explicitly marked `trending: true` receive the TRENDING label. Do not mark something trending without a real editorial or measured basis.
- The app has a refresh control. Once a public JSON feed URL is configured, it fetches the newest catalogue on refresh and falls back to the bundled starter collection if offline.
- This starter project does **not** have a hosted live feed yet. A genuinely growing feed needs new reviewed records to be published to a public source. It cannot create an endless supply of verified new prompts by itself.

## Connect a free public catalogue (GitHub Pages / raw GitHub)
1. Create a public GitHub repository, for example `build-him-feed`.
2. Copy `app/src/main/assets/prompts.example.json` to the repository as `prompts.json`.
3. Add new records to the `prompts` array. Keep each image URL and its exact matching prompt in the same object. Give every record a unique `id`.
4. Use a raw URL like `https://raw.githubusercontent.com/YOUR_USERNAME/build-him-feed/main/prompts.json`.
5. Put that URL into `PROMPT_FEED_URL` near the top of `MainActivity.kt` (replace the empty string), then build a new APK.
6. To publish new prompts later, update `prompts.json` in GitHub. Users tap refresh or reopen the app to fetch the updated catalogue. No app update is needed for catalogue-only changes.

Suggested record:
```json
{
  "id": "unique-2026-001",
  "title": "Editorial Portrait",
  "category": "Portrait",
  "imageUrl": "https://example.com/the-exact-image.jpg",
  "prompt": "The prompt that describes this exact image...",
  "negativePrompt": "blur, watermark...",
  "aspectRatio": "4:5",
  "tags": "portrait, editorial",
  "trending": false,
  "trendScore": 0,
  "publishedAt": 1793491200
}
```

## Honest current status
- The app UI and remote-feed loading logic are included in this source project.
- `PROMPT_FEED_URL` is intentionally blank until a public feed repository exists. Until then, the app uses its starter catalogue.
- The starter catalogue contains sample images and their authored prompts. Before a public release, visually review every pair; the app cannot independently prove an external image's semantic match.
- `Trending` in the starter feed is curated sample ordering, not verified live search analytics. For real-world trend claims, update the feed based on sources and record when it was checked.

## Build APK
1. Upload the contents of this project to a GitHub repository.
2. Open GitHub Actions and run **Build Android APK** (or push to `main`).
3. Download the `Build-Him-debug-apk` artifact from the successful workflow.
4. Share the APK. Recipients may need to allow installation from that source.

Alternatively, open the folder in Android Studio with JDK 17 and Android SDK 35, sync Gradle, then Build > Build APK(s).

## Privacy
The app has no login system and no provider API keys. It loads catalogue images and (when configured) prompt metadata over HTTPS. The user's own photo is not uploaded by BUILD HIM.
